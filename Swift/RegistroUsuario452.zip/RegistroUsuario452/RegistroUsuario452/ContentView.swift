//
//  ContentView.swift
//  RegistroUsuario452
//
//  Created by José Molina on 22/08/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        Text("Hello, World!")
    }
}

#Preview {
    ContentView()
    
}
